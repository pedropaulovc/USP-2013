
This directory contains few examples regarding to 
resource failure functionalities.
Here are the summary of what each example does:

example01: 
	shows a very basic example, dealing with 1 user, 3 resources and 1 GIS entities.

example02: 
	shows a basic example, dealing with 20 users, 6 resources and 1 GIS entities.

example03: 
	shows a more complex example,
	dealing with 30 users, 15 resources and 3 GIS entities.
	However, you can modify these parameters as you wish, 
	but keep in mind that the simulation might run longer
	if you increase the numbers.

NOTE: Detailed explanations are provided in the source file(s).

