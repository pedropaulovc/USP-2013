
/**
 * Author: Anthony Sulistio
 * Date: March 2005
 */

NOTE: This example uses Java Random class to select a resource and user entity 
      to communicate to a regional GIS entity. 
      Hence, when running this example many times, the values will be different.
