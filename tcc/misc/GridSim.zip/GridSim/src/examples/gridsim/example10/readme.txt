/**
 * Author: Anthony Sulistio
 * Date: May 2004
 */

NOTE: This example uses Java Random class to select a resource entity to
      process a Gridlet. Hence, when running this example many times,
      the values are different.
